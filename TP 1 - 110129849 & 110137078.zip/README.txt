Alunos: 
	Luís Felipe de Melo Nunes - 11/0129849 - Usuário Git: SirRandoom
	Rafael Koji - 11/0137078 - Usuário Git: RafaelKoji

Reposítório GitHub:
	https://github.com/SirRandoom/Trabalho-Pratico-PS
	
Compilando e Executando o Programa:
	Inicialmente deve-se extrair os arquivos enviados em zip para um diretório a ser utilizado. Para compilar basta abrir um terminal apontando para o diretório em que os arquivos foram extraídos e utilizar o comando make junto ao makefile enviado com os módulos, executando a main (./main) após o termino da compilação para iniciar o programa.

Obs: é necessário ter a biblioteca ncurses instalada para compilação correta.
Obs2: A CUnit utilizada é para sitemas 64 bits.
	
Funções do Programa:
F4 - finaliza o programa
setas direcionais - movimenta peças durante o jogo

