#include <curses.h>
#include <stdio.h>
#include <stdlib.h>

void inicia_ncurses();
void finaliza_ncurses();
int pega_input(int input);
