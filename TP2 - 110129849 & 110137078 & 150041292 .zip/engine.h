/** \file */

#define ENGINE_H

extern void inicia_ncurses(); 
extern void finaliza_ncurses();
extern int pega_input(int input);


